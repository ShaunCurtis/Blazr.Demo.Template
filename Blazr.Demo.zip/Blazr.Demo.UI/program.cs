﻿global using $ext_safeprojectname$.Core;
