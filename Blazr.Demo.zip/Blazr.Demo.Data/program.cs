﻿global using $ext_projectname$.Core;
global using System.Net.Http.Json;
