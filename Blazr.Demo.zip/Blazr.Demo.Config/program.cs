﻿global using $ext_projectname$.Core;
global using $ext_projectname$.Data;
global using Microsoft.Extensions.DependencyInjection;
