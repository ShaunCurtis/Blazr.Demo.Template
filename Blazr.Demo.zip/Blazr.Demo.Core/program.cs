﻿global using $ext_projectname$.Core;
global using System.Collections.Generic;
global using System.Threading.Tasks;
